
<!DOCTYPE html>
<html>

<head>
    
    
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Tranzit - Home of Awesome Trade</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />
    
    
    <!--index new-->
     

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <link rel="icon" href="https://tranzit.com.ng/t/admin/images/TranzitPay.gif">


  <style>
    * {
  box-sizing: border-box;
}

.dropbtn {
  background-color: none;
  color: black;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;

  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  
}

.nav-item {
    background:transparent;
    color:white;
    /*border-top: 2px solid transparent ;*/
    border-bottom: 2px solid transparent;
    height: 60px;
    transition: 0.5s;
    font-size:14px;
}
.nav-item:hover {
    background:#f4f8089c;
    color:white;
    /*border-top: 2px solid black;*/
    border-bottom: 2px solid yellow;
    transition: 0.5s;
    border-radius:5px;
    font-size:17px;
}

/*============================================================*/

.animate-charcter
{
   text-transform: uppercase;
  background-image: linear-gradient(
    -225deg,
    #231557 0%,
    #44107a 29%,
    #ff1361 67%,
    yellow 100%
  );
  background-size: auto auto;
  background-clip: border-box;
  background-size: 200% auto;
  color: #fff;
  background-clip: text;
  text-fill-color: transparent;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: textclip 2s linear infinite;
  display: inline-block;
  font-size: 110px;
}

.header_fixed {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
}

/*===========================================================*/

  </style>
<!-- Meta Pixel Code -->
<script>
// !function(f,b,e,v,n,t,s)
// {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
// n.callMethod.apply(n,arguments):n.queue.push(arguments)};
// if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
// n.queue=[];t=b.createElement(e);t.async=!0;
// t.src=v;s=b.getElementsByTagName(e)[0];
// s.parentNode.insertBefore(t,s)}(window, document,'script',
// 'https://connect.facebook.net/en_US/fbevents.js');
// fbq('init', '759971422290297');
// fbq('track', 'PageView');
 <!--</script>-->
 <!--<noscript><img height="1" width="1" style="display:none"-->
<!--src="https://www.facebook.com/tr?id=759971422290297&ev=PageView&noscript=1"-->
<!--</noscript>-->
<!-- End Meta Pixel Code -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-9DN6HLT8ZH"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-9DN6HLT8ZH');
</script>
</head>

<body id="default_theme" class="home_page1">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container pt-3">
          <a class="navbar-brand" href="">
            <img src="https://tranzit.com.ng/t/admin/images/TranzitPay.gif" alt="" /><span>
             <h3 style="font-size:20px" class="animate-charcter"><b> TranzitPay</b> </h3></h5>
            </span>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
              <ul class="navbar-nav  ">
                <li class="nav-item active">
                  <a class="nav-link" href="index">Home <span class="sr-only">(current)</span></a>
                </li>
                <!--<li class="nav-item">-->
                <!--  <a class="nav-link" href="#"> About</a>-->
                <!--</li>-->
        <li></li>
<!--                 <div class="dropdown nav-item">-->
<!--<a class="dropbtn nav-link">Services</a>-->
<!--<div class="dropdown-content">-->
<!--<a href="#data">Data</a>-->
<!--<a href="#vtu">Vtu Airtime</a>-->
<!--<a href="#convert">Airtime 2 Cash</a>-->
<!--<a href="#cable">Cable Tv</a>-->
<!--<a href="#">Exam Pin</a>-->

<!--</div>-->
<!--</div>-->
                <li class="nav-item">
                  <a class="nav-link" href="register">Register</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="loginn">Login</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="../account/dashboard">Dashboard</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="pricing">Pricing</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="services">Niche</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="testimonies">Testimonies</a>
                </li>
                 <li class="nav-item">
                  <a class="nav-link" href="https://documenter.getpostman.com/view/12457234/2s9YJdWNYJ">API</a>
                </li>
                  <li class="nav-item">
                   <a class="nav-link" href="about">AboutUs</a>   
                </li>
              </ul>
              
              
            <!--<div class="quote_btn-container ml-0 ml-lg-4 d-flex justify-content-center">-->
            <!--  <a href="">-->
            <!--    About Us-->
            <!--  </a>-->
            <!--</div>-->
          </div>
        </nav>
      
     </header>

</body>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<!--<link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">-->
<!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

<!-- bootstrap css -->
     
<!------ Include the above in your HEAD tag ---------->


<style>
@import url(https://fonts.googleapis.com/css?family=Roboto:400,100,900);

@import url(https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,600,700,900);
@import url('https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
@import url('https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
@import url(https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,500i,700,700i);
@import url('https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700');
html,

body {
  -moz-box-sizing: border-box;
       box-sizing: border-box;
  height: 100%;
  width: 100%; 
  background: #FFF;
  font-family: 'Roboto', sans-serif;
  font-weight: 400;
}
 
.wrapper {
  display: table;
  height: 100%;
  width: 100%;
}

.container-fostrap {
  display: table-cell;
  padding: 1em;
  text-align: center;
  vertical-align: middle;
}
.fostrap-logo {
  width: 100px;
  margin-bottom:15px
}
h1.heading {
  color: #fff;
  font-size: 1.15em;
  font-weight: 900;
  margin: 0 0 0.5em;
  color: #505050;
}
@media (min-width: 450px) {
  h1.heading {
    font-size: 3.55em;
  }
}
@media (min-width: 760px) {
  h1.heading {
    font-size: 3.05em;
  }
}
@media (min-width: 900px) {
  h1.heading {
    font-size: 3.25em;
    margin: 0 0 0.3em;
  }
} 
.card {
  display: block; 
    margin-bottom: 20px;
    line-height: 1.42857143;
    background-color: #fff;
    border-radius: 2px;
    box-shadow: 0 2px 5px 0 #f2db18,0 2px 10px 0 #f2db18; 
    transition: box-shadow .25s; 
}
.card:hover {
  box-shadow: 0 8px 17px 0  #032154,0 6px 20px 0  #032154;
}
.img-card {
  width: 100%;
  height:200px;
  border-top-left-radius:2px;
  border-top-right-radius:2px;
  display:block;
    overflow: hidden;
}
.img-card img{
  width: 100%;
  height: 200px;
  object-fit:cover; 
  transition: all .25s ease;
} 
.card-content {
  padding:15px;
  text-align:left;
}
.card-title {
  margin-top:0px;
  font-weight: 700;
  font-size: 1.65em;
}
.card-title a {
  color: #000;
  text-decoration: none !important;
}
.card-read-more {
  border-top: 1px solid #D4D4D4;
}
.card-read-more a {
  text-decoration: none !important;
  padding:10px;
  font-weight:600;
  text-transform: uppercase
}

/* john function img*/
.image {
   
    position:relative;
    -webkit-animation:glide 2s ease-in-out alternate infinite;
}
@-webkit-keyframes glide {
    from {left:0px; top:0px;}
    to {left:0px; top:20px;}
}


.animate-charcter
{
   text-transform: uppercase;
  background-image: linear-gradient(
    -225deg,
    #231557 0%,
    #44107a 29%,
    #ff1361 67%,
    yellow 100%
  );
  background-size: auto auto;
  background-clip: border-box;
  background-size: 200% auto;
  color: #fff;
  background-clip: text;
  text-fill-color: transparent;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: textclip 2s linear infinite;
  display: inline-block;
  font-size: 40px;
}
@keyframes textclip {
  to {
    background-position: 100% center;
  }
}

.glow {
  font-size: 25px;
  font-family: cursive;
  color: #fff;
  text-align: center;
  animation: glow 1s ease-in-out infinite alternate;
}




#about-section {
 
    position: relative;
    
}

.blockabout {
    padding: 20px;
    background: white;
}

.blockabout-inner {
    padding: 30px;
    border: 1px solid rgba(32, 33, 36, 0.1);
}

.sosmed-horizontal a i {
    border: 1px solid #070707;
    border-radius: 50%;
    color: #070707;
    display: inline-block;
    height: 30px;
    width: 30px;
    line-height: 30px;
    margin: auto 3px;
    font-size: 15px;
    text-align: center;
    transition: all 0.3s;
}

.rey-btn {
    border: 2px solid #070707;
    padding: 10px 40px;
    text-transform: uppercase;
    letter-spacing: 2px;
    font-size: 13px;
    font-weight: 700;
    border-radius: 50px;
    transition: all 0.3s;
}




.market-btn {
    display: inline-block;
    padding: 0.3125rem 0.875rem;
    padding-left: 2.8125rem;
    -webkit-transition: border-color 0.25s ease-in-out, background-color 0.25s ease-in-out;
    transition: border-color 0.25s ease-in-out, background-color 0.25s ease-in-out;
    border: 1px solid #e7e7e7;
    background-position: center left 0.75rem;
    background-color: #fff;
    background-size: 1.5rem 1.5rem;
    background-repeat: no-repeat;
    text-decoration: none;
}
.market-btn .market-button-title {
    display: block;
    color: #222;
    font-size: 1.125rem;
}
.market-btn .market-button-subtitle {
    display: block;
    margin-bottom: -0.25rem;
    color: #888;
    font-size: 0.75rem;
}
.market-btn:hover {
    background-color: #f7f7f7;
    text-decoration: none;
}
.apple-btn {
    background-image: url(data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAgMCAzMDUgMzA1IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCAzMDUgMzA1OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCI+CjxnIGlkPSJYTUxJRF8yMjhfIj4KCTxwYXRoIGlkPSJYTUxJRF8yMjlfIiBkPSJNNDAuNzM4LDExMi4xMTljLTI1Ljc4NSw0NC43NDUtOS4zOTMsMTEyLjY0OCwxOS4xMjEsMTUzLjgyQzc0LjA5MiwyODYuNTIzLDg4LjUwMiwzMDUsMTA4LjIzOSwzMDUgICBjMC4zNzIsMCwwLjc0NS0wLjAwNywxLjEyNy0wLjAyMmM5LjI3My0wLjM3LDE1Ljk3NC0zLjIyNSwyMi40NTMtNS45ODRjNy4yNzQtMy4xLDE0Ljc5Ny02LjMwNSwyNi41OTctNi4zMDUgICBjMTEuMjI2LDAsMTguMzksMy4xMDEsMjUuMzE4LDYuMDk5YzYuODI4LDIuOTU0LDEzLjg2MSw2LjAxLDI0LjI1Myw1LjgxNWMyMi4yMzItMC40MTQsMzUuODgyLTIwLjM1Miw0Ny45MjUtMzcuOTQxICAgYzEyLjU2Ny0xOC4zNjUsMTguODcxLTM2LjE5NiwyMC45OTgtNDMuMDFsMC4wODYtMC4yNzFjMC40MDUtMS4yMTEtMC4xNjctMi41MzMtMS4zMjgtMy4wNjZjLTAuMDMyLTAuMDE1LTAuMTUtMC4wNjQtMC4xODMtMC4wNzggICBjLTMuOTE1LTEuNjAxLTM4LjI1Ny0xNi44MzYtMzguNjE4LTU4LjM2Yy0wLjMzNS0zMy43MzYsMjUuNzYzLTUxLjYwMSwzMC45OTctNTQuODM5bDAuMjQ0LTAuMTUyICAgYzAuNTY3LTAuMzY1LDAuOTYyLTAuOTQ0LDEuMDk2LTEuNjA2YzAuMTM0LTAuNjYxLTAuMDA2LTEuMzQ5LTAuMzg2LTEuOTA1Yy0xOC4wMTQtMjYuMzYyLTQ1LjYyNC0zMC4zMzUtNTYuNzQtMzAuODEzICAgYy0xLjYxMy0wLjE2MS0zLjI3OC0wLjI0Mi00Ljk1LTAuMjQyYy0xMy4wNTYsMC0yNS41NjMsNC45MzEtMzUuNjExLDguODkzYy02LjkzNiwyLjczNS0xMi45MjcsNS4wOTctMTcuMDU5LDUuMDk3ICAgYy00LjY0MywwLTEwLjY2OC0yLjM5MS0xNy42NDUtNS4xNTljLTkuMzMtMy43MDMtMTkuOTA1LTcuODk5LTMxLjEtNy44OTljLTAuMjY3LDAtMC41MywwLjAwMy0wLjc4OSwwLjAwOCAgIEM3OC44OTQsNzMuNjQzLDU0LjI5OCw4OC41MzUsNDAuNzM4LDExMi4xMTl6IiBmaWxsPSIjMmUyZTJlIi8+Cgk8cGF0aCBpZD0iWE1MSURfMjMwXyIgZD0iTTIxMi4xMDEsMC4wMDJjLTE1Ljc2MywwLjY0Mi0zNC42NzIsMTAuMzQ1LTQ1Ljk3NCwyMy41ODNjLTkuNjA1LDExLjEyNy0xOC45ODgsMjkuNjc5LTE2LjUxNiw0OC4zNzkgICBjMC4xNTUsMS4xNywxLjEwNywyLjA3MywyLjI4NCwyLjE2NGMxLjA2NCwwLjA4MywyLjE1LDAuMTI1LDMuMjMyLDAuMTI2YzE1LjQxMywwLDMyLjA0LTguNTI3LDQzLjM5NS0yMi4yNTcgICBjMTEuOTUxLTE0LjQ5OCwxNy45OTQtMzMuMTA0LDE2LjE2Ni00OS43N0MyMTQuNTQ0LDAuOTIxLDIxMy4zOTUtMC4wNDksMjEyLjEwMSwwLjAwMnoiIGZpbGw9IiMyZTJlMmUiLz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K);
}
.google-btn {
    background-image: url(data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAgMCA1MTIgNTEyIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1MTIgNTEyOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjUxMnB4IiBoZWlnaHQ9IjUxMnB4Ij4KPHBvbHlnb24gc3R5bGU9ImZpbGw6IzVDREFERDsiIHBvaW50cz0iMjkuNTMsMCAyOS41MywyNTEuNTA5IDI5LjUzLDUxMiAyOTkuMDA0LDI1MS41MDkgIi8+Cjxwb2x5Z29uIHN0eWxlPSJmaWxsOiNCREVDQzQ7IiBwb2ludHM9IjM2OS4wNjcsMTgwLjU0NyAyNjIuMTc1LDExOS40NjcgMjkuNTMsMCAyOTkuMDA0LDI1MS41MDkgIi8+Cjxwb2x5Z29uIHN0eWxlPSJmaWxsOiNEQzY4QTE7IiBwb2ludHM9IjI5LjUzLDUxMiAyOS41Myw1MTIgMjYyLjE3NSwzODMuNTUxIDM2OS4wNjcsMzIyLjQ3IDI5OS4wMDQsMjUxLjUwOSAiLz4KPHBhdGggc3R5bGU9ImZpbGw6I0ZGQ0E5NjsiIGQ9Ik0zNjkuMDY3LDE4MC41NDdsLTcwLjA2Myw3MC45NjFsNzAuMDYzLDcwLjk2MWwxMDguNjg4LTYyLjg3N2M2LjI4OC0zLjU5Myw2LjI4OC0xMS42NzcsMC0xNS4yNyAgTDM2OS4wNjcsMTgwLjU0N3oiLz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==);
}
.windows-btn {
    background-image: url(data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCIgdmlld0JveD0iMCAwIDQ4MCA0ODAiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDQ4MCA0ODA7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGc+Cgk8cGF0aCBkPSJNMC4xNzYsMjI0TDAuMDAxLDY3Ljk2M2wxOTItMjYuMDcyVjIyNEgwLjE3NnogTTIyNC4wMDEsMzcuMjQxTDQ3OS45MzcsMHYyMjRIMjI0LjAwMVYzNy4yNDF6IE00NzkuOTk5LDI1NmwtMC4wNjIsMjI0ICAgbC0yNTUuOTM2LTM2LjAwOFYyNTZINDc5Ljk5OXogTTE5Mi4wMDEsNDM5LjkxOEwwLjE1Nyw0MTMuNjIxTDAuMTQ3LDI1NmgxOTEuODU0VjQzOS45MTh6IiBmaWxsPSIjMDBiY2YyIi8+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==);
}
.amazon-btn {
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTExIDc5LjE1ODMyNSwgMjAxNS8wOS8xMC0wMToxMDoyMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0idXVpZDo1RDIwODkyNDkzQkZEQjExOTE0QTg1OTBEMzE1MDhDOCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpGQUJGNjhGNDRGNkMxMUU3OUY5REJEQzBGNkVBQUI5QiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpGQUJGNjhGMzRGNkMxMUU3OUY5REJEQzBGNkVBQUI5QiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo2QUM1ODJFMkIxNEExMUUzQkY1NEUzQkNCRjlEODA1RSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo2QUM1ODJFM0IxNEExMUUzQkY1NEUzQkNCRjlEODA1RSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgNXCVIAAAc7SURBVHja5FwJbFRVFH0tQimgUCiubKJCWWSwKIooVhG3aESkETRqBEEEEURExBXiVhElkRiIEFwTQEHciQiIMQhFkUGFihErIJjWUgg0LFXqPf4z9jvMTOe/v9ebnEw78+//b85/y7n33T8ZNTU1yo5FIhEdtxMEXQRtBGcLOglO5ftoUKagSrBLUCLYKCgVbBEcNJ8oGo0qN+045Z2dJCgU9BdcJ2igcY4DgsWC9wTvetHoTA+u0ZlfCL3hJcFATXJgzQS3C5YIKgWT3G58hotDDMNlvmCQy9+hAj1ThtqqMPWgywXlHpADayVYKTfq0bAQdJ9guaCR8tamCUlPBZ2gcYIXlH82RUgaFlSCCgQzlf82T0hqFzSCGgreUsGxqUEj6BkKvaBYofSi5kERihCAE2z4rxYs4qp3WNBY0F0wVtBC85xNKUrnBoGgUdBTGn4IH24UbEvwGQh7TDBdMNGGQA3EELtGw2eh4Jwk5JjtAcFDmu0633clLeMcweYOi24IOLta9CnR6BF/CE4Whf2Xnz3oKg2fJzR8PtTwyaXK9nWIHbF4PFIYn2hcZ6Vm+5r4SpB039c5T5RwqO0VHE3hgoByv8alSm3oM99XsecJxSUaUXyOoKPgTOIMEjdK8xrVYSbIbIeIMsGPDp43Q/lkmap+W0bQepDTliU43oam+bM+EIT5qZcyEve5nL9aCtpzHmtq49zVYSOoraCv4AZBHgPc3P/7EOsgGCoYzt4SKnOTIAyZGYJrwzzLu0XQi4Lx9WEZdJqg0wVfqmAlzwJDUB/BmvompJwiqLND5FQwXtuujJ3TA1TlmM8eDytB2P9absMfaVbshryN+DeJuDsrzATNor7RMezV3xvkWMwWQZFIpIe8jNB0v0kZuedAm91gdaSm31iL5NSEjiDuO92h4bqGwzIUMaOdHnSe0ktpztfwaRwqgqT3QAheqHnNZZoyIlQ9COT00/BDzrpcwy9fs51ZfhEEXdJRw+8AdY9XBPm2q4HyklM0/HRqE7H3f4mN2NAXgrKUXgUZihGsVl0Mt7GKDfKLIAyTIxp+2cqoj7bSeybb+H5DZEE5zQ+CsEn4u6avlb2x2cpI2tuxiX4Q9JOquzIjmaHOuXcax6H0ZaADK/V46UW9vCYIavgLG43+XHBRks9QLP6B3TsfZ6/pOmqXv8hdGSAvn9psOIiap4zcD5bkQsINQ+agKBqN/uZVjFOsjAdLsm2co4DwwhAgY5/sfk9iMbkT++TlVRUus7zTajfdMcvjL7hEWa9oi9llclMf9JQgueBmVVv64rY9p4yiz9kW/VC01U33YRcnqjtQQLXWZXIeFsTu/tOC9Wn6oR6yPW+kljmViOrDRp/rMDEourpeHVujiJ60VaXOEy0TYq72K9RIZEigLXbwfNBZJ6rEBZw7Uugo2CtOkOM0QbDBmAyVveqybwUDGMFXpDjuG5W4bmiKkDPSqS/0r1A8PEfvAZneL+ck+wgJNVR1RIhEuRkEvHhUcyNJhWwosdgElNEsYGA7pnh05ZI0fJARRSF7W8Z6hxhbQtv9+k+64q7tx8xBmEca2gwh4odIMYce5qaWJKkBswEQbfvZIPSGn1XqCtnEanV0ZYncpNHKKLz6uI7DeyojGwr0IlHZvFEoPF/H6AAPDO+J70GLKPNxwC10qC92heBJ3qx0rEh60OT4HnQrleZQ3s1xIVTKiexKVbtRUEEgL76XqyBSx/GZx6aJlnl0+5s5JlH0hO2Z25i/2RpigjaRgHKKxkTWjcMrRsy+VKsYHvp/n39fyskTlWKtQ0rQbmVU6lelOOYHwXem/0vrWuYhzpaa/p9A7TFJ+biJ55BlUZVv4nSiuHDE6icxOa9KRwehEnVu3ImLBDuV8Qhm85AR04TtRvufVcZvhtzNz9qYRshazsFpCUVUbsTX5eARI8zwSDwh2ZUfcGIwv8yh3kK7c00TdkxQ9jcdP9Oqkp7GSbsqwUw/jBpmC4dh94CQAvF4D1X59ySieZwK72wSpbGNhF9UXDFYusHqR7woqsAuSNKgGSaBCE21QfCVh6REGHoMZqiSzCBdzFUpOaYg+0470fxOqu0pglQ/AdFP1e7bl/IubuHEt07pPS8Wbw05tLHK9mDYkFeHTzV7/Jtx76PCLYOB9kqnYrF8jtWLLX4xSPrNXHrLuWJgQizj31Uc9kd58zBf4PmzTozsWzPm6mJxkXiHwndX3PvNTOFOh/8sdQliMSu2gb1kiDJ+qyPdffpGjId6ejTs0HORrF+R5PNWXKnHuJXuWMCAD3tY21Rw7GtGAV1TkKPYc0aoFNvoTuWDZlBoTWLj/LIV7NUISt8IYsJsOhtXoIxk/l4PSNlMZYzJGj/stNDJk7tVHLmaeIQTeV9qqTxOjHasjAm2pZwL17nJvtvVo8gQfEZMZXKqHXVHPlekFswgNFK1JXPwO8gVZg/lwnpKht1ejtm/BRgAKCaVSdcawG4AAAAASUVORK5CYII=);
}
.market-btn-light {
    border-color: rgba(255, 255, 255, 0.14);
    background-color: rgba(0, 0, 0, 0);
}
.market-btn-light .market-button-title {
    color: #fff;
}
.market-btn-light .market-button-subtitle {
    color: rgba(255, 255, 255, 0.6);
}
.market-btn-light:hover {
    background-color: rgba(255, 255, 255, 0.06);
}
.market-btn-light.apple-btn {
    background-image: url(data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAgMCAzMDUgMzA1IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCAzMDUgMzA1OyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCI+CjxnIGlkPSJYTUxJRF8yMjhfIj4KCTxwYXRoIGlkPSJYTUxJRF8yMjlfIiBkPSJNNDAuNzM4LDExMi4xMTljLTI1Ljc4NSw0NC43NDUtOS4zOTMsMTEyLjY0OCwxOS4xMjEsMTUzLjgyQzc0LjA5MiwyODYuNTIzLDg4LjUwMiwzMDUsMTA4LjIzOSwzMDUgICBjMC4zNzIsMCwwLjc0NS0wLjAwNywxLjEyNy0wLjAyMmM5LjI3My0wLjM3LDE1Ljk3NC0zLjIyNSwyMi40NTMtNS45ODRjNy4yNzQtMy4xLDE0Ljc5Ny02LjMwNSwyNi41OTctNi4zMDUgICBjMTEuMjI2LDAsMTguMzksMy4xMDEsMjUuMzE4LDYuMDk5YzYuODI4LDIuOTU0LDEzLjg2MSw2LjAxLDI0LjI1Myw1LjgxNWMyMi4yMzItMC40MTQsMzUuODgyLTIwLjM1Miw0Ny45MjUtMzcuOTQxICAgYzEyLjU2Ny0xOC4zNjUsMTguODcxLTM2LjE5NiwyMC45OTgtNDMuMDFsMC4wODYtMC4yNzFjMC40MDUtMS4yMTEtMC4xNjctMi41MzMtMS4zMjgtMy4wNjZjLTAuMDMyLTAuMDE1LTAuMTUtMC4wNjQtMC4xODMtMC4wNzggICBjLTMuOTE1LTEuNjAxLTM4LjI1Ny0xNi44MzYtMzguNjE4LTU4LjM2Yy0wLjMzNS0zMy43MzYsMjUuNzYzLTUxLjYwMSwzMC45OTctNTQuODM5bDAuMjQ0LTAuMTUyICAgYzAuNTY3LTAuMzY1LDAuOTYyLTAuOTQ0LDEuMDk2LTEuNjA2YzAuMTM0LTAuNjYxLTAuMDA2LTEuMzQ5LTAuMzg2LTEuOTA1Yy0xOC4wMTQtMjYuMzYyLTQ1LjYyNC0zMC4zMzUtNTYuNzQtMzAuODEzICAgYy0xLjYxMy0wLjE2MS0zLjI3O 5C0wLjI0Mi00Ljk1LTAuMjQyYy0xMy4wNTYsMC0yNS41NjMsNC45MzEtMzUuNjExLDguODkzYy02LjkzNiwyLjczNS0xMi45MjcsNS4wOTctMTcuMDU5LDUuMDk3ICAgYy00LjY0MywwLTEwLjY2OC0yLjM5MS0xNy42NDUtNS4xNTljLTkuMzMtMy43MDMtMTkuOTA1LTcuODk5LTMxLjEtNy44OTljLTAuMjY3LDAtMC41MywwLjAwMy0wLjc4OSwwLjAwOCAgIEM3OC44OTQsNzMuNjQzLDU0LjI5OCw4OC41MzUsNDAuNzM4LDExMi4xMTl6IiBmaWxsPSIjRkZGRkZGIi8+Cgk8cGF0aCBpZD0iWE1MSURfMjMwXyIgZD0iTTIxMi4xMDEsMC4wMDJjLTE1Ljc2MywwLjY0Mi0zNC42NzIsMTAuMzQ1LTQ1Ljk3NCwyMy41ODNjLTkuNjA1LDExLjEyNy0xOC45ODgsMjkuNjc5LTE2LjUxNiw0OC4zNzkgICBjMC4xNTUsMS4xNywxLjEwNywyLjA3MywyLjI4NCwyLjE2NGMxLjA2NCwwLjA4MywyLjE1LDAuMTI1LDMuMjMyLDAuMTI2YzE1LjQxMywwLDMyLjA0LTguNTI3LDQzLjM5NS0yMi4yNTcgICBjMTEuOTUxLTE0LjQ5OCwxNy45OTQtMzMuMTA0LDE2LjE2Ni00OS43N0MyMTQuNTQ0LDAuOTIxLDIxMy4zOTUtMC4wNDksMjEyLjEwMSwwLjAwMnoiIGZpbGw9IiNGRkZGRkYiLz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K);
}
.market-btn-light.amazon-btn {
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTExIDc5LjE1ODMyNSwgMjAxNS8wOS8xMC0wMToxMDoyMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0idXVpZDo1RDIwODkyNDkzQkZEQjExOTE0QTg1OTBEMzE1MDhDOCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1QjFCQzQ2QjRGNkQxMUU3OUY5REJEQzBGNkVBQUI5QiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1QjFCQzQ2QTRGNkQxMUU3OUY5REJEQzBGNkVBQUI5QiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo2QUM1ODJFMkIxNEExMUUzQkY1NEUzQkNCRjlEODA1RSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo2QUM1ODJFM0IxNEExMUUzQkY1NEUzQkNCRjlEODA1RSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pk2CzRIAAAcFSURBVHja5FxpbBZVFH2ULlhQCq2oiBWLWqCI0AoqKILgGo2KEqlGjSKKIuJaC9EgRKNYURL9YQ2KawKICO5RqZYYsKDFtS1VsSpaU2ypgQYo0HpP5lTGz2/pvNnrTU7yLXNn3px5775777tvurW3tysf5DDBEMEAwUmCEwX9+TsalCRoEfwuqBF8KagTVAt2e9nQZA+vdYRgimCi4GJBd41z7BK8LlgjeMOTVqMHuYxcwRrBgXZnZYegyO32d3NxiGG4LBVMdvkZN7JnfuzGyZNcavQkwXYPyIFkCsoED4SFoDsFHwpSPTb8CwQPO31Sp4fYbMFi5a9MEzwfRILGu2UHNORYwS9BGmIpgldVcGR+0GzQI3T0giKY1XoHZYjBAazHuTT1ywUrOOvtFfQQDBPMEmTYaNd0wZIgOIrzNB29zYKcBOcuseFIljjhKDoxxC7U0FkuGCnYmuC4ewVzNNt1ahCGGILNXy3qIOAcalEHAWuuRZ0/BUcKDvhppM/X0HlQQ+dtDZ0setm+zmKtFo9HCuM9jeuUabYv3e90x0uCfvReewoOZZAai3g4kjs1rlNnwz8LVKjRgwT1EeQIjicGCdoEM5gEsyonCGo19PIEVUFKmO0hGgRbnIwZ/fI4k1TXFtvEJgf8BtNo13R9mv1dgSDYpwJlJO6zaL/6MiLPofHXlX1hI+gYwVjBZYLBDHCz/u9DbKCgkK7AoLAZMTcJwpBZJLgozFbeLYKeFNzRFaZBpwk6TvCpClbyLDAEnS5Y39UcKacIynWInEbGa0i471DGUnMD7dk8XzxNB2IxrH/9wClcR5BmxVLRa4KvYjh3urEY4sAf/e5BT9sg5ynB7UGOxewSNFwZyXEduVIZyfpAi91g9SZNvVkWyWkPI0FYd7peQ289h2UoYkY7BI1SeinNpRo6PcJGEBzBMZq672u6EaEiCOSM09BrVsYKqlXJ12xnml8EwS/J0dDbRb/HK4LS/SIoW3CUhp5O4SbW/s+yERv6QlCa0qsgy1DWqy6m2ZjFJvtFEIZJq4beIcqoj7bSe4pt3N9UwdF+EIT1+D80dWdYOPYZZSTt7cg9fhD0vUpcmRFLrhOM7sRxJYJLHZipkbgr8JogeMPrbDT6E8EZMf7rJXjL7pOPkBf9SHecI/jAZsNB1HPKyP1gSp5CuCHIHCwU/OYVQZiN6ml4wyJPCO72Khb7S/CCCpfs93KIQVAp9p2HN7iKQbJOgu5spVHHbTcfhNKSxz0i5zHB5Zz6rQiKtvKUbpG7Q9uGNrS7K3Mjrrexk3pVgsygbIfaJDjF4V6DoqtL1H9rFDHEahPkiZBWucB2CxzegLbSwV5TnuDpF8TRfdape3Jjl94EQY0NYioFkzp5rdFR9Oe4suNwb2m2Xlh/c8xNNUiooarjZCJabgYBL2oWsWl3C92GGotNQBnNMga2M+U+VnVCBxnRkRyqiPX2MLbcKPjZfF/mNAKWjlNshhBmWccLjqJt6kuSujMbgOKmnWzQF8pY4GuznFYoza6Rm7lVGYVX7yY4fASzoWMYn/Wno4sHhcLzCkYH2DDc9C8/SC60gm4+DriaCl1FzhU8xIfVGVkopBdH9qBr6GkW8mnODqGnHE3OUwcXChoJ5MWbOQvmRMk8/lP2lxyRBLuKYxJFT1ieuZb5m9oQE/Q1CdhOpzGa5HF49TSFUTE9aWz6f5OfJ9B4olLs8JAShIC6Lg45iuHSN6bvdYlCDThnq03f72IWsUj5uIjnkCCffh97ViF/w8TRUT/ZZA5L4sViqERdEnFi5FO2KWMLZu+QEZPOdqP9jyrjnSG38L8BphHymTKVzCQKVlG5EVm4hC1GxUw8IdmVH3BiYF9K6W+h3Vkmg91RfDHRdPxiq9H8AhrtliiW/gb6MNUchsMCQgqcx9sEmwXfkghzj0ebc01OacdCwk/KeCmCijaLxZN3eFFUgZ0Wo0GLTA4ifKpKwQYPSYG3ji0LVzAdHEvgupirUvqYguwbIw+2siC3jd72XBX/FRDj1MF1+zo+xWoavgqlt18sUlI4tDHLDmfYMDiBzj72+FcifkeFGyrY8NqdspgZRYuxWD7H6pkWb6yVSbZ6+iVNNIgN/NzCYd/Ghwd7gf1nKOLsR0OKmGuIxUliJR3fyL1qvUzhzsBoMabukm4le8lUJsI7u06fynhohEfDDj0X1WxrY/yfyZl6plsp12UM+LCGtVUFRz5nFDA0DjmKPWe6irOM7tSGukV0tIrYOL9kLXs1gtKXnTih0zsOS9i48cpI5jd7QEoVPWMYa7zYabmTJ3erOLKcuJ+GfCx9qcE0jHakgQm21bSFFW6y73b1KDIEHxHzmZzKpt+RzxkpgxmEVHWwZA56uznDNNFd2ESXod7LMfu3AAMA3eQjZHI91/8AAAAASUVORK5CYII=);
}
h1,
h2,
h3,

h5,
h6 {
    letter-spacing: 0;
    font-weight: normal;
    position: relative;
    padding: 0;
    font-weight: normal;
    line-height: normal;
    color: #1f1f1f;
    margin: 0
}
h2 {
    font-size: 54px;
    font-weight: 500;
    letter-spacing: -2px;
    position: relative;
    margin-bottom: 25px;
    line-height: 50px;
    position: relative;
}
.slide_banner1 {
    background-image: url('n/images/slide1.png');
    min-height: 650px;
    position: relative;
    background-repeat: no-repeat;
    background-size: auto;
    background-position: bottom center;
}
.full {
    width: 100%;
    float: left;
    margin: 0;
    padding: 0;
}
    .slide_cont h2 {
        font-size: 30px;
        line-height: 34px;
    }
    .slide_pc_img img {
        width: 100%;
        margin-left: 0;
        margin-top: 35px;
        right: inherit;
    }
    .slide_pc_img {
    position: relative;
    z-index: 1;
    margin-bottom: 0;
    display: flex;
    justify-content: center;
    width: 100%;
}
    .slide_cont {
        margin-top: 100px;
    }
    .slide_cont {
        margin: 50px 0 100px;
    }
    .slide_cont h2 {
        font-size: 28px;
        line-height: 34px;
    }
    .slide_cont {
        margin: 50px 0 100px;
    }
    /*.slide_cont {*/
    /*    margin-top: 115px;*/
    /*}*/
    .slide_pc_img img {
        width: 100%;
        margin-left: 0;
        margin-top: 30px;
        right: 0;
    }
    .slide_pc_img {
        position: relative;
        z-index: 1;
        margin-bottom: 0;
    }
    .slide_banner1 {
        min-height: auto;
    }
  .service{
      width:auto;
      height:auto;
  }
  .service .card .card-img-top {
  width: 90px;
  margin: 55px auto 5px auto;
}
.service .card {
  text-align: center;
  box-sizing: none;
  position: relative;
}

.service .card .card-title {
  color:  #f2db18;
}
.service_section .card:hover {
  cursor: pointer;
  border: none;
  border-radius: 0;
  -webkit-box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.2);
  -moz-box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.2);
  box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.2);

}

.layout_padding {
    padding-top: 0;
    padding-bottom: 100px;
}
    .layout_padding {
        margin: 0 !important;
    }

.heading_main {
    width: 100%;
    margin: 0 0 65px;
    letter-spacing: 0;
}

.app-features li {

    padding-left: 100px;
    position: relative;
    margin: 25px 0 0;
    float: left;
    border-bottom: dotted 1px #ddd;
    padding-bottom: 25px;
    list-style-type:none;
}

.app-features li > i {
    position: absolute;
    left: 0;
    width: 90px;
    height: 90px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 100px;
    background: #fff;
    font-size: 35px;
    font-weight: 500;
    transition: ease all 0.5s;
    top: 0;
    border: solid #0aceb1 2px;
    color: #0aceb1;
}

.app-features ul li:last-child {
    border-bottom: none;
}

.app-features li:hover > i,
.app-features li:focus > i {
    background: #1e72bc;
    border-color: #1e72bc;
    color: #fff;
}

.app-features h4 {
    text-transform: none;
    font-weight: 500;
    color: #666;
    margin-top: 10px;
    margin-bottom: 10px;
}
 .test {
     color:gray;
     font-size:14px;
     
 }

.btn {
    background:#f2db18;
    color:black;
    width:150px;
    height:50px;
    font-size:12px;
    border:none;
    border-radius:20px;
    /*box-shadow:5px 10px 18px gray;*/
    transition: 0.5s;
}

.btn:hover{
    background:silver;
    color:white;
    font-size:16px;
    transition: 0.5s;
    box-shadow:5px 10px 15px gray;
}

.btn1 {
    background:#f2db18;
    color:black;
    width:150px;
    height:50px;
    font-size:12px;
    border:none;
    border-radius:20px;
    /*box-shadow:5px 10px 18px gray;*/
    transition: 0.5s;
}

.btn1:hover{
    background:silver;
    color:white;
    font-size:14px;
    transition: 0.5s;
    box-shadow:5px 10px 15px gray;
}

.btn-2 {
    background:#f2db18;
    color:black;
    width:140px;
    height:50px;
    font-size:14px;
    border:none;
    border-radius:20px;
    /*box-shadow:5px 10px 18px gray;*/
    transition: 0.5s;
}

.btn-2:hover{
    background:silver;
    color:white;
    font-size:16px;
    transition: 0.5s;
    box-shadow:5px 10px 15px gray;
}
 .btn2 {
    background:#f2db18;
    color:white;
    width:230px;
    height:55px;
    font-size:14px;
    border:none;
    border-radius:30px;
    /*box-shadow:5px 10px 18px gray;*/
    transition: 0.5s;
}

.btn2:hover{
    background:silver;
    color:white;
    font-size:16px;
    text-decoration:none;
    transition: 0.5s;
    box-shadow:5px 10px 15px gray;
}

.api{
        border:none;
        background-color:lightgray;
        width:100%;
        height:270px;
        margin-top:60px;
        color:black;
        /*font-size:30px;*/
        /*font-weight:bold;*/
        display:flex;
        justify-content:center;
        align-items:center;
    }
</style>

<body>
      <section id="banner_parallax" class="slide_banner1">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="full">
                     <div class="slide_cont">
                        <h2 style="color:white;"><b>WELCOME TO <br/><span class="animate-charcter">TranzitPay</span></b></h2>
                        
                        <h6 style="color:sliver;"><p> At Tranzit Tranzit-Tech we offer services that are fast, affordable and accessible. Our delivery in the tech market is one you would want to very much invest in....
Our company is registered under CAC with RC number - 2946316.</p></h6>
                          <a href="register"><button type="button" class="btn">Sign Up</button></a>
                          <a href="loginn"><button type="button" class="btn">Login</button></a>
                        <!--<div class="full slide_bt"> <a class="white_bt bt_main" href="index.html">Download</a> </div>-->
                        <!--<div class="full slide_bt"> <a class="white_bt bt_main" href="index.html">Download</a> </div>-->
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="full">
                     <div class="slide_pc_img wow fadeInRight" data-wow-delay="1s" data-wow-duration="2s"> <img class="image" src="images/laptpt.png" alt="#" /> </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      
      <br/>
                          <!--<i class="fa fa-signal" aria-hidden="true"></i>-->

      <br>
       <section class="service layout_padding ">
    <div class="container">

      <div style="font-size:150%;"class="word"></div>
      
      <p class="custom_heading-text">
        Note: Transactions Via This Website Is Instant Because This Site Is 95% Automated.
      </p>
      <div class=" layout_padding2">
        <div class="card-deck">
                   <div class="card">
            <img class="card-img-top" src="images/tele.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Telecom</h5>
              <p class="card-text">
                We deploy the best technology, which ensures E-wallet safety and free
                flowing and fast transactions on telecom services
              </p>
              <hr>
               <a href="telecom_services" ><button type="button" class="btn-2">
                               GET STARTED</button></a>
            </div>
          </div>

            
          <div class="card">
            <img class="card-img-top" src="images/programming.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Programming</h5>
              <p class="card-text">
                  Experience the power of tech, take a glimps at our oustanding website structure, remember the future is tech.
              </p>
              <hr>
               <a href="programming_services" ><button type="button" class="btn-2">
                              GET STARTED</button></a>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="images/digital-1.png" alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Digital-Currencies</h5>
              <p class="card-text">
               Trade on the go with TranzitPay super user friendly trading platform for digital currencies exchange.
              </p>
              <hr>
              <!--digitalCurrency_services-->
                   <a href="../account/coming_soon"><button type="button" class="btn-2">
                             GET STARTED</button></a>
            </div>
          </div>
          
          
        </div>
      </div>
    
    </div>
  </section>
  
        <section class="layout_padding layer_style">
            <center>
         <div class="container">
            <div class="row">
               <div class="col-sm-12">
                  <div class="full text_align_center">
                     <div class="heading_main center_head_border heading_style_1">
                        <h2><b><span class="animate-charcter">TranzitPay </span> <span style="color:gold; font-size:50px;">Features</span></b></h2>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row app-features">
               <div class="col-md-4 col-sm-6 col-xs-12">
                  <ul class="features-left">
                     <li>
                         <!--<i class="fa fa-shopping-cart" aria-hidden="true"></i>-->
                        <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <div class="fl-inner">
                           <h5>AUTOMATION</h5>
                           <p class="test">Transactions done on this website is instant because it 95% automated... </p>
                        </div>
                     </li>
                     <li>
                    <i class="fa fa-signal" aria-hidden="true"></i>
                    <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <div class="fl-inner">
                           <h5>CUSTOMER SERVICE</h5>
                           <p class="test">We prioritize our customers needs and the deliver the best... </p>
                        </div>
                     </li>
                     <li>
                        <i class="fa fa-rss" aria-hidden="true"></i>
                        <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <div class="fl-inner">
                           <h5>SWIFT TRADING</h5>
                           <!--<p class="test">Trading made easier, trade with ease and get credited instantly...</p>-->
                           <p class="test">
                           Trades performed gets credited instantly with transparency...</p>
                        </div>
                     </li>
                     <li>
                        <i class="fa fa-money" aria-hidden="true"></i>
                        <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <div class="fl-inner">
                           <h5>AUTOMATED BANK PAYMENT</h5>
                           <p class="test">Funding made faster, our automated bank payment transfer reflects automatically...</p>
                        </div>
                     </li>
                     <li>
                        <!--<i class="fa fa-barcode" aria-hidden="true"></i> -->
                        <i class="flaticon-line-graph"></i>
                        <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <div class="fr-inner">
                           <h5>E-WALLET SECURITY</h5>
                           <!--<p class="test">You can save your fund on our E-wallet, note we have deploy safety measure to safeguard all E-wallet funds... </p>-->
                           <p class="test">Funds are safe on the site, secured with privacy guaranteed...</p>
                        </div>
                     </li>
                  </ul>
               </div>
               <div class="col-md-4 col-sm-6 col-xs-12">
                  <ul class="features-right">
                     <li>
                        <i class="fa fa-bolt" aria-hidden="true"></i>
                        <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <div class="fr-inner">
                           <h5>INTER TRANSFER</h5>
                           <p class="test">Cash transfer from a user wallet to another user is at no cost with no hidden charges... </p>
                        </div>
                     </li>
                     <li>
                        <i class="fa fa-desktop" aria-hidden="true"></i>
                        <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <!--<i class="flaticon-cloud-computing"></i>-->
                        <div class="fr-inner">
                           <h5>API</h5>
                           <p class="test">We have provided Interested developers with a 
                            simple and friendly designed API for Integration... </p>
                        </div>
                     </li>
                     <li>
                        <i class="fa fa-barcode" aria-hidden="true"></i> 
                        <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <!--<i class="flaticon-line-graph"></i>-->
                        <div class="fr-inner">
                           <h5>REAL RESPONSE</h5>
                           <p class="test">Status and providers response on transactions initiated are transient... </p>
                        </div>
                     </li>
                     <li>
                         <!--<i class="fa fa-cc-visa" aria-hidden="true"></i>-->
                        <i class="flaticon-coding"></i>
                        <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <div class="fr-inner">
                           <h5>FAST TRANSACTION</h5>
                           <p class="test">Pending or failed transactions are resolved with immediate effect, we deliver in seconds... </p>
                        </div>
                     </li>
                     <li>
                         <i class="fa fa-cc-visa" aria-hidden="true"></i>
                         <i class="fa fa-credit-card" aria-hidden="true"></i>
                        <!--<i class="flaticon-coding"></i>-->
                        <div class="fr-inner">
                           <h5>ENCRYPTION</h5>
                           <!--<p class="test">Note your details like passwords are encrypted before transmitting into our database, transmission of users details to third parties are highly prohabited... </p>-->
                           <p class="test">Personal details are encrypted and users information are not shared to third parties...</p>
                        </div>
                     </li>
                  </ul>
               </div>
               <div  class="col-md-4 wow fadeInRight" data-wow-delay="0.5" data-wow-duration="1s">
                  <div class="full">
                     <div class="center">
                        <img style="width:90%; height:400px;" src="images/Mockup.png" alt="#" />
                     </div>
                  </div>
               </div >
            </div>
         </div>
         </center>
      </section>
      <br/>
      
      <section style="box-shadow: 0 2px 5px 0 #f2db18,0 2px 10px 0 #f2db18;" id="about-section" class="pt-5 pb-5">
    <div class="container wrapabout">
        <div class="red"></div>
        <div class="row">
            <div class="col-lg-6 align-items-center justify-content-left d-flex mb-5 mb-lg-0">
                <div class="blockabout">
                    <div style="background-color: 0 2px 1px 0 #f2db18,0 2px 2px 0 #f2db18;"class="blockabout-inner text-center text-sm-start">
                        <div class="title-big pb-3 mb-3">
                            <h3>Developer API</h3>
                        </div>
                        <p style="color:black;text-align: justify"class="description-p text-muted pe-0 pe-lg-0">
                            We have provided interested developers with a simple and friendly designed API for Integration.
                            
                        </p>
                        <p style="color:black;text-align: justify"class="description-p text-muted pe-0 pe-lg-0">This easy and straight-forward API are available for the integration of our various services into your projects.</p>
                        <div class="sosmed-horizontal pt-3 pb-3">
                            <i class="fa fa-facebook"></i>
                            <i class="fa fa-instagram"></i>
                            <i class="fa fa-pinterest"></i>
                        </div>
                        <a href="https://documenter.getpostman.com/view/12457234/2s9YJdWNYJ"><button class="btn2">View Documentary</button></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mt-5 mt-lg-0">
               <center>
                <figure class="potoaboutwrap">
                    <div class="api">
                       
                    <img style="box-shadow: 0 5px 10px 0 whitesmoke,0 5px 10px 0 whitesmoke; max-width: 80%;
        max-height: 320px;
        display: block; "src="n/images1/api3.gif" alt="potoabout" />
        
       
                </figure>
                </center>
            </div>
        </div>
    </div>
</section>
<br/>
<br/>

<div class="container">
 <center> 
<div class="container">
  <div class="row">
    <div class="col-md-12 text-center">
      <h3 style="font-size:100%" class="animate-charcter"><b>Download <span style="font-size:150%">Tranzit</span> from your App Stores</b></h3>
    </div>
  </div>
</div>


<!-- App Store button -->
<a href="../account/coming_soon" target="_blank" class="market-btn apple-btn" role="button">
  <span class="market-button-subtitle">Available on</span>
  <span class="market-button-title">App Store</span>
</a>
&nbsp;&nbsp;
<!-- Google Play button -->
<a href="../account/coming_soon" target="_blank" class="market-btn google-btn" role="button">
  <span class="market-button-subtitle">Available on</span>
  <span class="market-button-title">Google Play</span>
</a>
<br/>
<div class="col-lg-6 mt-5 mt-lg-0">
                <figure class="potoaboutwrap">
                    <img class="image" style="width: 200px%;
        height: 300px;
        display: block; "src="images/phoo.png" alt="potoabout" />
                </figure>
            </div>
            
           

  </center> 
</div>

      
      <html>
<div class="container-1 my-5">

  <!-- Footer -->
  <footer
          class="text-center text-lg-start text-white"
          style="background-color: gray"
          >
    <!-- Section: Social media -->
    <section
             class="d-flex justify-content-between p-4"
             style="background-color: #f2db18"
             >
      <!-- Left -->
      <div class="me-5">
        <span>Connected with us on:</span>
      </div>
      <!-- Left -->

      <!-- Right -->
      <div>
        <a href="https://api.whatsapp.com/send?phone=+2348069195863&text=Helloo" class="text-white me-4">
          <i class="fab fa-whatsapp"></i>
        </a>
        <a href="https://instagram.com/tranzit_tech?igshid=YmMyMTA2M2Y=" class="text-white me-4">
          <i class="fab fa-instagram"></i>
        </a>
        <a href="https://www.facebook.com/tranzitpay?mibextid=LQQJ4d" class="text-white me-4">
          <i class="fab fa-facebook"></i>
        </a>
        <a href="https://t.me/tranzitpay" class="text-white me-4">
          <i class="fab fa-telegram"></i>
        </a>
        <a href="https://linkedin.com/tranzitpay" class="text-white me-4">
          <i class="fab fa-linkedin"></i>
        </a>
    </div>
      <!-- Right -->
    </section>
    <!-- Section: Social media -->

    <!-- Section: Links  -->
    <!--<section class="">-->
    <!--  <div class="container text-center text-md-start mt-5">-->
        <!-- Grid row -->
    <!--    <div class="row mt-3">-->
          <!-- Grid column -->
    <!--      <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">-->
            <!-- Content -->
    <!--        <h6 class="text-uppercase fw-bold">TranzitPay</h6>-->
    <!--        <hr-->
    <!--            class="mb-4 mt-0 d-inline-block mx-auto"-->
    <!--            style="width: 60px; background-color: #f2db18; height: 2px"-->
    <!--            />-->
    <!--        <p>-->
    <!--          TranzitPay is -->
    <!--            Registered company with RC Number - 2946316. -->
    <!--            We specialise on major telecom services like Data sales,-->
    <!--            Convertion Of Airtime, Website Creation & Many More...-->
    <!--        </p>-->
    <!--      </div>-->
          <!-- Grid column -->

          <!-- Grid column -->
          
          <!-- Grid column -->

          <!-- Grid column -->
          
          <!-- Grid column -->

          <!-- Grid column -->
    <!--      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">-->
            <!-- Links -->
    <!--        <h6 class="text-uppercase fw-bold">Contact</h6>-->
    <!--        <hr-->
    <!--            class="mb-4 mt-0 d-inline-block mx-auto"-->
    <!--            style="width: 60px; background-color: #f2db18; height: 2px"-->
    <!--            />-->
    <!--        <p><i class="fas fa-home mr-3"></i> No. 19,Jehovahjieh complex along Poultry Road, Ujmen-Ekpoma, Edo State</p>-->
    <!--        <p><i class="fas fa-envelope mr-3"></i>  +2348069195863</p>-->
    <!--        <p><i class="fas fa-envelope mr-3"></i>info@tranzit.com.ng</p>-->
    <!--        <p><i class="fas fa-phone mr-3"></i> info@tranzit.com.ng</p>-->
    <!--      </div>-->
          <!-- Grid column -->
    <!--    </div>-->
        <!-- Grid row -->
    <!--  </div>-->
    <!--</section>-->
    <!-- Section: Links  -->

    <!-- Copyright -->
    <div
         class="text-center p-3"
         style="background-color: rgba(0, 0, 0, 0.2)"
         >
      Copyright &copy; 2023 All Rights Reserved      <br/>
      <a href="https://www.tranzit.com.ng/NEW/n/"><span style="color: #f2db18"><b> TranzitPay</b></span></a>
        
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->

</div>
  <!-- footer section -->

  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>

  

<script>
var words = ['TRANZIT TECH GLOBAL SERVICES', 'Smart And Reliable', 'OUR THREE NICHE NAMELY', 'TELECOM - Pay Utility Bills', 'PROGRAMMING - Experience The Power Of Tech', 'DIGITAL-CURRENCIES - Trade With Ease'],
    part,
    i = 0,
    offset = 0,
    len = words.length,
    forwards = true,
    skip_count = 0,
    skip_delay = 15,
    speed = 70;
var wordflick = function () {
  setInterval(function () {
    if (forwards) {
      if (offset >= words[i].length) {
        ++skip_count;
        if (skip_count == skip_delay) {
          forwards = false;
          skip_count = 0;
        }
      }
    }
    else {
      if (offset == 0) {
        forwards = true;
        i++;
        offset = 0;
        if (i >= len) {
          i = 0;
        }
      }
    }
    part = words[i].substr(0, offset);
    if (skip_count == 0) {
      if (forwards) {
        offset++;
      }
      else {
        offset--;
      }
    }
    $('.word').text(part);
  },speed);
};

$(document).ready(function () {
  wordflick();
});
</script>






</body>
</html>

      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA8eaHt9Dh5H57Zh0xVTqxVdBFCvFMqFjQ&callback=initMap"></script>

</body>